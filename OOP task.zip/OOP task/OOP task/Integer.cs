﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_task
{
    class Integer : INumber
    {
        private int _integer;
        private string _text;

        public Integer(int nr)
        {
            _integer = nr;
        }

        public void RunTasks()
        {
            Filter();
            PrintToScreen();
        }

        void PrintToScreen()
        {
            Console.WriteLine(_text);
        }

        public void Filter()
        {
            if (_integer % 3 == 0 && _integer % 5 == 0)
            {
                _text = "SneakyBox";
            }
            else if (_integer % 3 == 0)
            {
                _text = "Sneaky";
            }
            else if (_integer % 5 == 0)
            {
                _text = "Box";
            }
            else
            {
                _text = _integer.ToString();
            }
        }
    }
}
